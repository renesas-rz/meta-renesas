/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2022 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : evk_common.h
 * Description  : information and API for common functions
 ******************************************************************************/

#ifndef EVK_COMMON_H
#define EVK_COMMON_H

/*  Macro definitions */
#ifndef TRUE
#define TRUE		1U
#endif

#ifndef FALSE
#define FALSE		0U
#endif

#ifndef NULL
#define NULL    ((void*)0)
#endif  /* !defined(NULL) */

/*
 * Global Typedef definitions
 */
typedef enum
{
    CMN_SUCCESS = 0,
    CMN_ERROR   = -1
} e_evk_cmn_error_no_t;


struct st_boot_param {
    uint32_t size;
    uint32_t checksum;
    void *addr_load;
};

struct st_load_param {
    struct st_boot_param second_loader;
    struct st_boot_param u_boot;
    uint32_t *blok_buf;
};

/** 1st/2nd bootloader  basic information **/
#define BOOT_IMAGE_PARTITION            1
#define BOOT_PARAM_BLOCK_SIZE           1
#define BOOT_PARAM_LOAD_SIZE_OFFSEET    0
#define BOOT_PARAM_CHECKSUM_OFFSEET     4
#define BOOT_PARAM_ALIGNMENT            sizeof(uint32_t)
#define EMM_BLOCK_SIZ                   512
#define BASEADDR_RAMB0                  0xB6000000

/** 2nd bootloader information **/
#define SECOND_LOAD_MAIN_ADDR           0xB6000100    /* Execution start address for 2nd bootloader */
#define SECOND_LOADER_PARM              0x100         /* eMMC block number for Parameters */
#define SECOND_LOADER_BLOCK             0x101         /* eMMC block number for main date  */
#define SECOND_LOADER_MAX_SIZ           1024 * 1024

/** u-boot information **/
#define U_BOOT_ADDR                     0x08000000    /* Execution start address for uboot */
#define U_BOOT_PARM                     0x901         /* eMMC block number for Parameters */
#define U_BOOT_BLOCK                    0x902         /* eMMC block number for main date  */
#define U_BOOT_MAX_SIZ                  2*1024*1024


/******************************************************************************
 Prototype define
 *****************************************************************************/
void cmn_SYS_WriteReg(uint32_t offset, uint32_t value);
void CMN_InitSysCnt(void);
void CMN_DelayInUSec(uint64_t us);
uint64_t CMN_GetSysCnt(void);
uint32_t CMN_GetFreq4SysCnt(void);


/*******************************************************************************
 * Function Name: CMN_REG_Read32
 * Description  : read access to Register in uint32_t.
 *
 * Arguments    : addr  -  address for read access
 * Return Value : value -  read data.
 ******************************************************************************/
static inline uint32_t CMN_REG_Read32(uintptr_t addr)
{
    return *((volatile uint32_t *)addr);
}


/*******************************************************************************
 * Function Name: CMN_REG_Write32
 * Description  : write access to Register in uint32_t.
 *
 * Arguments    : addr  - address for write access
 *                value - write data
 * Return Value : non -
 ******************************************************************************/
static inline void CMN_REG_Write32(uintptr_t addr, uint32_t value)
{
    /** sizeof(uintptr_t) == sizeof(uint32_t *) */
    *((volatile uint32_t *)addr) = value;
}


/*******************************************************************************
 * Function Name: CMN_DelayInMS
 * Description  : Does an example task. Making this longer just to see how it
 *                wraps.
 * Arguments    : index    -  Where to start looking
 *                p_output -  Pointer of where to put the output data
 * Return Value : count    -  How many entries were found
 ******************************************************************************/
static inline void CMN_DelayInMS(uint64_t ms)
{
    CMN_DelayInUSec(ms * 1000ULL);
}


/*******************************************************************************
 * Function Name: CMN_DelayInUS
 * Description  : Does an example task. Making this longer just to see how it
 *                wraps.
 * Arguments    : index    - Where to start looking
 *                p_output - Pointer of where to put the output data
 * Return Value : count    - How many entries were found
 ******************************************************************************/
static inline void CMN_DelayInUS(uint64_t us)
{
    CMN_DelayInUSec(us);
}


#endif /* !defined(EVK_COMMON_H) */
