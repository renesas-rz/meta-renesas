/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2022 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    :common.c
 ******************************************************************************/
#include <stddef.h>
#include "types.h"
#include "common.h"
#include "devdrv.h"


int32_t PutStr(const char *str,char rtn)
{
    while(*str)
    {
        str++;
    }
    return(0);
}


uint32_t Hex2Ascii(int32_t hexdata,char *str,int32_t *chcnt)
{
	long i;
	char ch;

	for( i = 7; i >= 0; i-- )
	{
		ch = (char)(hexdata & 0x0F);

		if ( ch > 9 )
		{
			ch += 7;
		}

		ch += 0x30;
		hexdata >>= 4;
		*(str + i) = ch;
	}

	*(str + 8) = '\0';
	*chcnt = 8;

	return 0U;
}


/*- End of Filr -*/
