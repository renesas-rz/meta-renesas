/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2022 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : main.c
 ******************************************************************************/
#include <stdio.h>
#include "types.h"

#include "evk_gic.h"
#include "evk_uart.h"
#include "evk_emmc_hal.h"
#include "evk_emmc_std.h"
#include "evk_emmc_def.h"
#include "evk_emmc_cnf.h"
#include "evk_emmc_reg.h"
#include "evk_common.h"

/*-----------------------------------------------------------*/
int (*SecondLoaderMain)(void);

extern void InitPFC(void);
extern void InitCPG(void);
extern void PowerOnRAMB(void);
extern void UartSetup(void);

extern void get_bootparam(uint32_t *buf, struct st_boot_param *param);
extern BOOL sum_check(struct st_boot_param param);

int main(void)
{
    struct st_load_param boot_param;
    uint32_t boot_pram_buf[EMM_BLOCK_SIZ * BOOT_PARAM_BLOCK_SIZE / sizeof(uint32_t)];
    uint32_t read_block_size;
    uint8_t tmp_ret=0;

    /* initialize GIC driver */
    Init_GIC(0);

    /* Set Pin Function */
    InitPFC();

    /* Initialize CPG */
    InitCPG();

    /* Initialize RAMB */
    PowerOnRAMB();

    /* Initialize UART */
    UartSetup();

    uart0_print("[BL1] Boot Loader Version 1.3 for RZV2M\n");

    /* Initialize eMMC */
    if(EMMC_SUCCESS != emmc_init(FALSE))
    {
        /*- Error occurred -*/
        uart0_print("[BL1] [Error] emmc_init()\n");
    }else
    {
        /* Power control eMMC */
        if(EMMC_SUCCESS != emmc_memcard_power(TRUE))
        {
            /*- Error occurred -*/
            uart0_print("[BL1] [Error] emmc_memcard_power()\n");
        }else
        {
            /* Mount control eMMC */
            if(EMMC_SUCCESS != emmc_mount())
            {
                /*- Error occurred -*/
                uart0_print("[BL1] [Error] emmc_mount error()\n");
            }else
            {
                /* Access partition control eMMC */
                if(EMMC_SUCCESS != emmc_select_partition(BOOT_IMAGE_PARTITION))
                {
                    /*- Error occurred -*/
                    uart0_print("[BL1] [Error] emmc_select_partition()\n");
                }else
                {
                    /* Initialization operation ends normally */
                    uart0_print("[BL1] eMMC initialized\n");
                    tmp_ret = 1;
                }
            }
        }
    }

    /*- Check the execution result of the initialization operation -*/
    if(tmp_ret)
    {
        /* Load 2ndbootlaoder to RAMB */
        boot_param.blok_buf = boot_pram_buf;
        boot_param.second_loader.addr_load = (void*)BASEADDR_RAMB0;

        /* Load boot parameter for 2nd loader */
        if(EMMC_SUCCESS != emmc_read_sector(boot_param.blok_buf,
                    SECOND_LOADER_PARM,
                    BOOT_PARAM_BLOCK_SIZE,
                    LOADIMAGE_FLAGS_DMA_ENABLE))
        {
            /*- Error occurred -*/
            uart0_print("[BL1]  [Error] emmc_read_sector() for 2nd boot loader parameter\n");
        }else
        {
            uart0_print("[BL1] Loaded the boot parameter for 2nd boot\n");

            /* Load boot parameter for 2nd bootloader */
            get_bootparam(boot_param.blok_buf, &boot_param.second_loader);

            /* Check that the expected maximum size of the 2nd bootloader is not exceeded */
            if(SECOND_LOADER_MAX_SIZ < boot_param.second_loader.size)
            {
                /*- Error occurred -*/
                uart0_print("[BL1] [Error] Over size the 2nd boot loader\n");
            }else
            {
                read_block_size = boot_param.second_loader.size / EMM_BLOCK_SIZ;

                if(0 < boot_param.second_loader.size % EMM_BLOCK_SIZ)
                {
                    read_block_size += 1;
                }

                /* Load the 2nd loader */
                if(EMMC_SUCCESS !=
                    emmc_read_sector((uint32_t *)boot_param.second_loader.addr_load,
                    SECOND_LOADER_BLOCK, read_block_size, 0))
                {
                    /*- Error occurred -*/
                    uart0_print("[BL1]  [Error] emmc_read_sector() for 2nd boot loader\n");
                }else
                {
                    /* Checksum for 2nd bootloader */
                    if(TRUE != sum_check(boot_param.second_loader))
                    {
                        /*- Error occurred -*/
                        uart0_print("[BL1]  [Error] sum_check() for 2nd boot loader\n");
                    }else
                    {
                        /*- The acquisition process of 2nd bootloader was completed normally -*/
                        uart0_print("[BL1] Loaded the 2nd boot loader\n");

                        /* Start 2nd bootloader */
                        uart0_print("[BL1] the 2nd bootloader start\n");
                        SecondLoaderMain = (void*)SECOND_LOAD_MAIN_ADDR;
                        SecondLoaderMain();

                        /* Set control Flag -*/
                        tmp_ret = 0x0f;
                    }
                }
            }
        }
    }

    /*- Check the execution result of the initialization operation -*/
    if(tmp_ret != 0x0f)
    {
        /* Error detected and operation terminated */
        uart0_print("[BL1] [Error] 1st loader is failed");
    }

    while(1)
    {
        __asm("nop");
        __asm("nop");
        __asm("nop");
    }

    return 0;
}


/* End of file -*/
