/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2022 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : evk_HWSetup.c
 ******************************************************************************/

#include <stdbool.h>
#include <stdint.h>

#include "evk_cmn_cpg.h"
#include "evk_cmn_pmc.h"
#include "evk_common.h"
#include "evk_ddr_api.h"
#include "evk_cmn_icb.h"
#include "evk_uart.h"

static st_pmc_local_t gs_pmc_priv =
{
    .mem_time = 0x176F176F, /* PD_MEM External Power On/Off Wait: 2ms/2ms */
    .pwron_time = 0x176F,   /* PD External Power On Wait: 2ms */
};

static int32_t PowerOn_PD_MEM_FromPOR(void);


void PowerOnDDR(void)
{
	int32_t res;

	/* Power On DDR */
	res = PowerOn_PD_MEM_FromPOR();

	if(CMN_SUCCESS != res)
	{
		while (true) {
		}
	}
}

static int32_t PowerOn_PD_MEM_FromPOR(void)
{
    int32_t rslt;
    uint8_t tmp_md=0;

    do
    {
        CPG_SetClockCtrl(27, 0x0017, 0x0000);
        CPG_SetClockCtrl(16, 0x0020, 0x0000);
        CPG_SetClockCtrl(17, 0x0100, 0x0000);

        CPG_SetResetCtrl(7, 0x0002, 0x0000);

        CPG_SetPDResetCtrl(CPG_PD_RST_MEM_RSTB, CPG_PD_RST_MEM_RSTB);

        rslt = CPG_WakeUpPLL(CPG_PLL_3);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        PMC_WriteReg(PMC_PD_MEM_TIM, gs_pmc_priv.mem_time);

        rslt = pmc_TurnPower(PMC_PD_MEM, PMC_POWER_ON);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        CPG_SetClockCtrl(27, 0x0011, 0x0011);
        CMN_DelayInMS(210);

        rslt = pmc_TurnIsolation(PMC_PD_MEM, PMC_ISOLATION_OFF);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        CPG_SetClockCtrl(27, 0x0006, 0x0006);

        CPG_SetResetCtrl(15, 0x0008, 0x0008);

		CMN_DelayInMS(210);
        CPG_SetResetCtrl(15, 0x0010, 0x0010);

        MMC_InitialSetting();

        MMC_DisableRefAndPD();

        MMC_DisableSignal_dfi_init_complete();

        rslt = MMC_WaitBitForSW_Done();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        CPG_SetResetCtrl(15, 0x0005, 0x0005);

        CPG_SetResetCtrl(15, 0x0020, 0x0020);
        CMN_DelayInUS(1);

        CPG_SetResetCtrl(15, 0x0040, 0x0040);

        rslt = DDI_InitalizePHY();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        MMC_StartDfiInit();
        rslt = MMC_WaitBitForSW_Done();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }
        rslt = MMC_WaitBitForDFI_INIT_COMPLETE();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        MMC_EnableSignal_dfi_init_complete();
        rslt = MMC_WaitBitForSW_Done();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        rslt = MMC_WaitToDFI_NormalOperation();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        MMC_SetBackRegisters();

        DDI_DFI_InitComplete();

        MMC_EnablePort();

        CPG_SetResetCtrl(7, 0x0002, 0x0002);

        CMN_DelayInUS(5);

        CPG_SetClockCtrl(16, 0x0020, 0x0020);

        CPG_SetClockCtrl(17, 0x0100, 0x0100);

        rslt = pmc_ConnectBus(PMC_PD_MEM, PMC_BUS_CONNECT);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        rslt = ICB_SetDDRSche();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        cmn_SYS_WriteReg(0x020C, 0x00);
        DDI_MNRT_2nd_Initsetting();

        uart0_print("[BL2] DDR initialization completed_M_RZV2M_EVK\n");

        rslt = CMN_SUCCESS;
    }
    while (0);

    return rslt;
}

/*- End of File -*/
