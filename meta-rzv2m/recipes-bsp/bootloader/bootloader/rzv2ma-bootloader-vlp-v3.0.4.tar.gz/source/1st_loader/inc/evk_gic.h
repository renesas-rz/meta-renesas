/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2022 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : evk_gic.h
 * Description  : register and API information for GIC
 ******************************************************************************/

#ifndef EVK_GIC_H /* prevent circular inclusions */
#define EVK_GIC_H /* by using protection macros */

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/


/************************** Constant Definitions *****************************/
/* The maximum number of interrupts supported by the hardware.*/
#define GIC_MAX_NUM_INTR_INPUTS  426U /* Maximum number of interrupt */

/** @name Distributor Interface Register Map */
#define GIC_BASE_ADDRESS        (0x82000000)
#define GIC_CPU_BASE_ADDRESS    (0x20000)
#define GIC_DIST_BASE_ADDRESS   (0x10000)

#define GIC_DIST_EN_OFFSET      0x00000000U     /* Distributor Enable        */
#define GIC_IC_TYPE_OFFSET      0x00000004U     /* Interrupt Controller Type */
#define GIC_DIST_IDENT_OFFSET   0x00000008U     /* Implementor ID            */
#define GIC_SECURITY_OFFSET     0x00000080U     /* Interrupt Security        */
#define GIC_ENABLE_SET_OFFSET   0x00000100U     /* Enable Set                */
#define GIC_DISABLE_OFFSET      0x00000180U     /* Enable Clear              */
#define GIC_PENDING_SET_OFFSET  0x00000200U     /* Pending Set Register      */
#define GIC_PENDING_CLR_OFFSET  0x00000280U     /* Pending Clear             */
#define GIC_ACTIVE_SET_OFFSET   0x00000300U     /* Active Status Set         */
#define GIC_ACTIVE_CLR_OFFSET   0x00000380U     /* Active Status Clear       */
#define GIC_PRIORITY_OFFSET     0x00000400U     /* Priority Level            */
#define GIC_SPI_TARGET_OFFSET   0x00000800U     /* SPI Target : 0x800-0x8FB  */
#define GIC_INT_CFG_OFFSET      0x00000C00U     /* Interrupt Configuration 0xC00-0xCFC */
#define GIC_PPI_STAT_OFFSET     0x00000D00U     /* PPI Status                */
#define GIC_SPI_STAT_OFFSET     0x00000D04U     /* SPI Status :0xd04-0xd7C   */
#define GIC_AHB_CONFIG_OFFSET   0x00000D80U     /* AHB Configuration         */
#define GIC_SFI_TRIG_OFFSET     0x00000F00U     /* Software Triggered Interrupt */
#define GIC_PERPHID_OFFSET      0x00000FD0U     /* Peripheral ID             */
#define GIC_PCELLID_OFFSET      0x00000FF0U     /* Pcell ID                  */

/** CPU Interface Register Map  */
#define GIC_CONTROL_OFFSET      0x00000000U     /* CPU Interface Control */
#define GIC_CPU_PRIOR_OFFSET    0x00000004U     /* Priority Mask         */
#define GIC_BIN_PT_OFFSET       0x00000008U     /* Binary Point          */
#define GIC_EOI_OFFSET          0x00000010U     /* End of Interrupt      */
#define GIC_RUN_PRIOR_OFFSET    0x00000014U     /* Running Priority      */
#define GIC_HI_PEND_OFFSET      0x00000018U     /* Highest Pending Interrupt       */
#define GIC_ALIAS_BIN_PT_OFFSET 0x0000001CU     /* Aliased non-Secure Binary Point */

#define GIC_EN_INT_MASK         0x00000001U     /* Interrupt In Enable */
#define GIC_CPU_PROPERTY_MSK_STEP16  0xF0U


/***************** Macros (Inline Functions) Definitions *********************/
/****************************************************************************/
/**
* Read the Interrupt Configuration Register offset for an interrupt id.
* @param	InterruptID is the interrupt number.
* @return	The 32-bit value of the offset
* @note
*****************************************************************************/
#define GIC_INT_CFG_OFFSET_CALC(InterruptID) \
	((uint32_t)GIC_INT_CFG_OFFSET + (((InterruptID)/16U) * 4U))


/****************************************************************************/
/**
* Read the Interrupt Priority Register offset for an interrupt id.
* @param	InterruptID is the interrupt number.
* @return	The 32-bit value of the offset
* @note
*****************************************************************************/
#define GIC_PRIORITY_OFFSET_CALC(InterruptID) \
	((uint32_t)GIC_PRIORITY_OFFSET + (((InterruptID)/4U) * 4U))


/****************************************************************************/
/**
* Read the SPI Target Register offset for an interrupt id.
* @param	InterruptID is the interrupt number.
* @return	The 32-bit value of the offset
* @note
*****************************************************************************/
#define GIC_SPI_TARGET_OFFSET_CALC(InterruptID) \
	((uint32_t)GIC_SPI_TARGET_OFFSET + (((InterruptID)/4U) * 4U))


/****************************************************************************/
/**
* Read the Interrupt Clear-Enable Register offset for an interrupt ID
* @param	Register is the register offset for the clear/enable bank.
* @param	InterruptID is the interrupt number.
* @return	The 32-bit value of the offset
* @note
*****************************************************************************/
#define GIC_EN_DIS_OFFSET_CALC(Register, InterruptID) \
	((Register) + (((InterruptID)/32U) * 4U))


/****************************************************************************/
/**
* Write the given CPU Interface register
* @param    InstancePtr is a pointer to the instance to be worked on.
* @param    RegOffset is the register offset to be written
* @param    Data is the 32-bit value to write to the register
* @return   None.
* @note
*****************************************************************************/
#define GIC_CPUWriteReg( RegOffset, Data) \
	(GIC_WriteReg((GIC_CPU_BASE_ADDRESS + RegOffset), ((uint32_t)(Data))))


/****************************************************************************/
/**
* Write the given Distributor Interface register
* @param    InstancePtr is a pointer to the instance to be worked on.
* @param    RegOffset is the register offset to be written
* @param    Data is the 32-bit value to write to the register
* @return   None.
*****************************************************************************/
#define GIC_DistWriteReg(RegOffset, Data) \
	(GIC_WriteReg((GIC_DIST_BASE_ADDRESS + RegOffset), ((uint32_t)(Data))))


/************************** Function Prototypes ******************************/
void GIC_WriteReg(uint32_t offset, uint32_t value);
void Init_GIC(uint32_t cpu_id);

/************************** Variable Definitions *****************************/
#ifdef __cplusplus
}
#endif

#endif  /* !defined(EVK_GIC_H) */
