/*******************************************************************************
 * RENESAS CONFIDENTIAL
 * This source code is subject to non-disclosure agreement.
 ******************************************************************************/
/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2022 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : evk_cmn_pmc.c
 * Description  : operation functions for PMC
 ******************************************************************************/

#include <stdint.h>
#include <stdbool.h>

#include "evk_common.h"
#include "evk_cmn_pmc.h"
#include "evk_cmn_cpg.h"

#define PMC_TIMEOUT_UNIT_IN_US (10)
#define PMC_SEQUENCE_POWER_ON_TIMEOUT (500000)
#define PMC_ISOLATION_OFF_TIMEOUT (500000)
#define PMC_CONNECTED_BUS_TIMEOUT (500000)
#define PMC_SEPARATED_BUS_TIMEOUT (500000)
#define PMC_ISOLATION_ON_TIMEOUT (500000)
#define PMC_SEQUENCE_POWER_OFF_TIMEOUT (500000)
#define PMC_RELEASE_RESET_TIMEOUT (500000)

#define PMC_WAIT_EVENT(m_toc, m_err_code, m_condition, m_rslt)                 \
	{                                                                      \
		uint32_t count = (m_toc) / PMC_TIMEOUT_UNIT_IN_US;             \
		while (true) {                                                 \
			if ((m_condition)) {                                   \
				(m_rslt) = CMN_SUCCESS;                        \
				break;                                         \
			}                                                      \
			if ((0 == (m_toc)) || (0 < count)) {                   \
				CMN_DelayInUS(PMC_TIMEOUT_UNIT_IN_US);         \
				count--;                                       \
			} else {                                               \
				(m_rslt) = (m_err_code);                       \
				break;                                         \
			}                                                      \
		}                                                              \
	}

uint32_t PMC_ReadReg(uint32_t offset)
{
	return (CMN_REG_Read32(PMC_BASE_ADDRESS + offset));
}

void PMC_WriteReg(uint32_t offset, uint32_t value)
{
	CMN_REG_Write32((PMC_BASE_ADDRESS + offset), value);
}


int32_t pmc_TurnPower(e_pmc_kind_pd_t kind_pd, e_pmc_on_off_t on_flag)
{
    int32_t rslt = CMN_ERROR;
    uint32_t value;
    int32_t err_code;
    uint32_t timeout_c = 0;

    do
    {
        rslt = CMN_SUCCESS;
        switch (kind_pd)
        {
            case PMC_PD_MEM:
                value = PMC_SPLY_ENA_PD_MEM;
                break;
                
            default:
                rslt = PMC_ERROR_NO_EXIST_SPLY;
                break;
        }
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        if (PMC_POWER_ON == on_flag)
        {
            value |= PMC_SPLY_ENA_PD_ON;
            timeout_c = PMC_SEQUENCE_POWER_ON_TIMEOUT;
            err_code = PMC_ERROR_POWER_ON_TIMEOUT;
        }
        else
        {
            timeout_c = PMC_SEQUENCE_POWER_OFF_TIMEOUT;
            err_code = PMC_ERROR_POWER_OFF_TIMEOUT;
        }
        PMC_WriteReg(PMC_SPLY_ENA, value);

        PMC_WAIT_EVENT(timeout_c, err_code,
            (0 != (PMC_ReadReg(PMC_INT_STS) & PMC_INT_STS_PD_DONE)),
            rslt);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        PMC_WriteReg(PMC_INT_CLR, PMC_INT_CLR_PD_DONE);
    }
    while (0);

    return rslt;
}

int32_t pmc_TurnIsolation(e_pmc_kind_pd_t kind_pd, e_pmc_on_off_t on_flag)
{
    int32_t rslt = CMN_ERROR;
    uint32_t offset_reg_isoen = 0xFFFFFFFF;
    uint32_t value;
    int32_t err_code;
    uint32_t timeout_c = 0;

    do
    {
        rslt = CMN_SUCCESS;
        switch (kind_pd)
        {
            case PMC_PD_MEM:
                offset_reg_isoen = PMC_PD_MEM_ISOEN;
                break;
                
            default:
                rslt = PMC_ERROR_NO_EXIST_ISOLATION;
                break;
        }
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        if (PMC_ISOLATION_ON == on_flag)
        {
            /* Turn On Isolation */
            value = PMC_PD_ISO_EN;
            timeout_c = PMC_ISOLATION_ON_TIMEOUT;
            err_code = PMC_ERROR_ISOLATION_ON_TIMEOUT;
        }
        else
        {
            /* Turn Off Isolation */
            value = 0;
            timeout_c = PMC_ISOLATION_OFF_TIMEOUT;
            err_code = PMC_ERROR_ISOLATION_OFF_TIMEOUT;
        }
        PMC_WriteReg(offset_reg_isoen, value);

        /* wait turn isolation */
        PMC_WAIT_EVENT(timeout_c, err_code,
            (0 != (PMC_ReadReg(offset_reg_isoen) & PMC_PD_ISO_DONE)), rslt);
    }
    while (0);

    return rslt;
}

int32_t pmc_ConnectBus(e_pmc_kind_pd_t kind_pd, e_pmc_on_off_t on_flag)
{
    int32_t rslt = CMN_ERROR;
    uint32_t value;
    uint32_t offset_reg;
    uint32_t check_mask;
    uint32_t check_data = 0;
    uint32_t idle_check_mask;
    int32_t err_code;
    uint32_t timeout_c = 0;

    do
    {
        rslt = CMN_SUCCESS;
        switch (kind_pd)
        {
            case PMC_PD_MEM:
                value = PMC_IDLE_REQ_WEN_PD_MEM | 0x00000100UL;
                check_mask = PMC_IDLE_STS_PD_MEM_IDLE_DONE;
                break;

            default:
                rslt = PMC_ERROR_NO_EXIST_BUS_CONNECT;
                break;
        }
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        idle_check_mask = check_mask;
        if (PMC_BUS_CONNECT == on_flag)
        {
            offset_reg = PMC_IDLE_STS;
            check_data = 0;
            timeout_c = PMC_CONNECTED_BUS_TIMEOUT;
            err_code = PMC_ERROR_CONNECTED_BUS_TIMEOUT;
        }else
        {
            value |= (value >> 16);
            offset_reg = PMC_INT_STS;
            check_mask = PMC_INT_STS_IDLE_DONE;
            check_data = check_mask;
            timeout_c = PMC_SEPARATED_BUS_TIMEOUT;
            err_code = PMC_ERROR_SEPARATED_BUS_TIMEOUT;
        }
        PMC_WriteReg(PMC_IDLE_REQ, value);

        PMC_WAIT_EVENT(timeout_c, err_code,
                (check_data == (PMC_ReadReg(offset_reg) & check_mask)),
                rslt);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        if (PMC_BUS_CONNECT != on_flag)
        {
            PMC_WriteReg(PMC_INT_CLR, check_data);
            if (0 == (PMC_ReadReg(PMC_IDLE_STS) & idle_check_mask))
            {
                rslt = PMC_ERROR_NOT_IDLE_BUS;
            }
        }
    }
    while(0);

    return rslt;
}

/*- End of file -*/
