/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2022 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : evk_ddr_reg.h
 * Description  : registers information for MMC/DDI
 ******************************************************************************/

#ifndef EVK_DDR_REG_H
#define EVK_DDR_REG_H

#define DDI_BASE_ADDRESS            (0x00A0000000)
#define MMC_BASE_ADDRESS            (0x00A2000000)


/** DWC ddr umctl2 memory map */
#define MMC_STAT                    (0x0004)
#define MMC_PWRCTL                  (0x0030)
#define MMC_RFSHCTL3                (0x0060)
#define MMC_INIT0                   (0x00D0)
#define MMC_CTL0                    (0x0180)
#define MMC_DFIMISC                 (0x01B0)
#define MMC_DFISTAT                 (0x01BC)
#define MMC_DBG1                    (0x0304)
#define MMC_DBGCAM                  (0x0308)
#define MMC_SWCTL                   (0x0320)
#define MMC_SWSTAT                  (0x0324)
#define MMC_MP_PSTAT                (0x03FC)
#define MMC_MP_PCTRL0               (0x0490)


/** Bit assign defined (a part of MMC registers) */
#define MMC_STAT_OPERATING_MODE_MASK                (7 << 0)
#define MMC_STAT_SELFREF_TYPE_MASK                  (3 << 4)
#define MMC_STAT_SELFREF_STATE_MASK                 (3 << 8)
#define MMC_STAT_SELFREF_CAM_NOT_EMPTY              (1 << 12)

#define MMC_PWRCTL_SELFREF_EN                       (1 << 0)
#define MMC_PWRCTL_POWERDOWN_EN                     (1 << 1)
#define MMC_PWRCTL_DEEPPOWERDOWN_EN                 (1 << 2)
#define MMC_PWRCTL_EN_DIF_DRAM_CLK_DISABLE          (1 << 3)
#define MMC_PWRCTL_MPSM_EN                          (1 << 4)
#define MMC_PWRCTL_SELFREF_SW                       (1 << 5)
#define MMC_PWRCTL_STAY_IN_SELFREF                  (1 << 6)
#define MMC_PWRCTL_DIS_CAM_DRAIN_SELFREF            (1 << 7)
#define MMC_PWRCTL_LPDDR4_SR_ALLOWED                (1 << 8)

#define MMC_RFSHCTL3_DIS_AUTO_REFRESH               (1 << 0)
#define MMC_RESHCTL3_REFRESH_UPDATE_LEVEL           (1 << 1)

#define MMC_SWCTL_SW_DONE                           (1 << 0)
#define MMC_SWSTAT_SW_DONW_ACK                      (1 << 0)


#define MMC_DFIMISC_DFI_INIT_COMPLETE_EN            (1 << 0)
#define MMC_DFIMISC_PHY_DBI_MODE                    (1 << 1)
#define MMC_DFIMISC_DFI_DATA_CS_POLARITY            (1 << 2)
#define MMC_DFIMISC_SHARE_DFI_DRAM_CLK_DISABLE      (1 << 3)
#define MMC_DFIMISC_CTL_IDLE_EN                     (1 << 4)
#define MMC_DFIMISC_DFI_INIT_START                  (1 << 5)
#define MMC_DFIMISC_DIS_DYN_ADR_TRI                 (1 << 6)
#define MMC_DFIMISC_LP_OPTIMIZED_WRITE              (1 << 7)
#define MMC_DFIMISC_MRT_CLR                         0xFFFFF7FE
#define MMC_DFIMISC_MRT_SET                         0x00000801


#define MMC_DFISTAT_DFI_INIT_COMPLETE               (1 << 0)
#define MMC_DFISTAT_DFI_LP_ACK                      (1 << 1)


#define MMC_PCTRL_N_PORT_EN                         (1 << 0)



/** PHY Register */
#define DDI_DWC_DDRPHYA_MASTER0_MEMRESETL               (0x00080180)
#define DDI_DWC_DDRPHYA_MASTER0_CALRATE                 (0x00080220)
#define DDI_DWC_DDRPHYA_DRTUB0_UCCLKHCLKENABLES         (0x00300200)
#define DDI_DWC_DDRPHYA_APBONLY0_MICROCONTMUXSEL        (0x00340000)
#define DDI_DWC_DDRPHYA_APBONLY0_UCTSHADOWREGS          (0x00340010)
#define DDI_DWC_DDRPHYA_APBONLY0_DCTWRITEPROT           (0x003400C4)
#define DDI_DWC_DDRPHYA_APBONLY0_UCTWRITEONLYSHADOW     (0x003400C8)
#define DDI_DWC_DDRPHYA_APBONLY0_MICRORESET             (0x00340264)


/** SYS Register */
#define SYS_BASE_ADDRESS            (0xA3F03000)


/** SYS debug rejisuter */
#define GEN_REG0                    (0x0200)
#define GEN_REG1                    (0x0204)
#define GEN_REG2                    (0x0208)
#define GEN_REG3                    (0x020C)


#endif  /* !defined(EVK_DDR_REG_H) */
