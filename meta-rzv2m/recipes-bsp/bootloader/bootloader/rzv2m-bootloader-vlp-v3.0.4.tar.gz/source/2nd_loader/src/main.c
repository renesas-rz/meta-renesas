/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2022 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : main.c
 ******************************************************************************/
#include <stdio.h>
#include "types.h"

#include "evk_uart.h"
#include "evk_emmc_hal.h"
#include "evk_emmc_std.h"
#include "evk_emmc_def.h"
#include "evk_emmc_cnf.h"
#include "evk_emmc_reg.h"
#include "evk_common.h"

/*-----------------------------------------------------------*/
void (*u_boot)(void);

extern void PowerOnDDR(void);
extern void UartSetup(void);
extern void get_bootparam(uint32_t *buf, struct st_boot_param *param);
extern BOOL sum_check(struct st_boot_param param);

static void error_routine(void);

__attribute__((section(".entry")))
int main( void )
{
	struct st_load_param boot_param;
	uint32_t boot_pram_buf[EMM_BLOCK_SIZ*BOOT_PARAM_BLOCK_SIZE/sizeof(uint32_t)];
	uint32_t read_block_size;

	boot_param.blok_buf = boot_pram_buf;

	uart0_print("[BL2] 2nd boot loader entered for RZV2M_EVK\n");

	/*Init eMMC*/
	if(EMMC_SUCCESS != emmc_init(FALSE))
	{
		uart0_print("[BL2] [Error] emmc_init()\n");
		error_routine();
		return -1;
	};

	if(EMMC_SUCCESS != emmc_memcard_power(TRUE)){
		uart0_print("[BL2] [Error] emmc_memcard_power()\n");
		error_routine();
		return -1;
	};

	if(EMMC_SUCCESS != emmc_mount()){
		uart0_print("[BL2] [Error] emmc_mount()\n");
		error_routine();
		return -1;
	};

	if(EMMC_SUCCESS != emmc_select_partition(BOOT_IMAGE_PARTITION)){
		uart0_print("[BL2] [Error] emmc_select_partition()\n");
		error_routine();
		return -1;
	};

	/*- DDR setting -*/
	PowerOnDDR(); 

	/*return from 2nd Loader*/
	/*Load U-Boot to DDR*/
    boot_param.u_boot.addr_load = (void*)U_BOOT_ADDR;

	if(EMMC_SUCCESS != emmc_read_sector(boot_param.blok_buf, U_BOOT_PARM, BOOT_PARAM_BLOCK_SIZE, LOADIMAGE_FLAGS_DMA_ENABLE)){
		uart0_print("[BL2] [Error] emmc_read_sector() for U-Boot parameter\n");
		error_routine();
		return -1;
	}

	uart0_print("[BL2] Loaded the boot parameter for U-Boot\n");

	get_bootparam(boot_param.blok_buf,&boot_param.u_boot);
	if(U_BOOT_MAX_SIZ < boot_param.u_boot.size){
		uart0_print("[BL2] [Error] Over size the U-Boot\n");
		error_routine();
		return -1;
	}

	read_block_size = boot_param.u_boot.size / EMM_BLOCK_SIZ;
	if(0 < (boot_param.u_boot.size % EMM_BLOCK_SIZ)){
		read_block_size += 1;
	}

	if(EMMC_SUCCESS != emmc_read_sector((uint32_t*)boot_param.u_boot.addr_load, U_BOOT_BLOCK, read_block_size, LOADIMAGE_FLAGS_DMA_ENABLE)){
		uart0_print("[BL2] [Error] emmc_read_sector() for U-Boot\n");
		error_routine();
		return -1;
	}

	if(TRUE != sum_check(boot_param.u_boot)){
		uart0_print("[BL2] [Error] sum_check() for U-Boot\n");
		error_routine();
		return -1;
	}

	uart0_print("[BL2] Loaded the U-Boot\n");

	/*Call U-Boot*/
	uart0_print("[BL2] the U-Boot start\n");
    u_boot = (void*)U_BOOT_ADDR;
	u_boot();

    while(1){;} //not reach here.
	return 0;
}

static void error_routine(void)
{
	uart0_print("[BL2] 2nd boot loader is failed");	
}

/*- End of File -*/
