/*******************************************************************************
 * RENESAS CONFIDENTIAL
 * This source code is subject to non-disclosure agreement.
 ******************************************************************************/
/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2022 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : b_lpddr4_cfg_ddi_PinSwizzle_MA.h
 ******************************************************************************/
const st_ddi_setting_data_t gs_ddr_ddi_PinSwizzle[] = {
	{ .addr = (0 + 0x020100 * 4), .data = 0x0000 },
	{ .addr = (0 + 0x020101 * 4), .data = 0x0001 },
	{ .addr = (0 + 0x020102 * 4), .data = 0x0002 },
	{ .addr = (0 + 0x020103 * 4), .data = 0x0003 },
	{ .addr = (0 + 0x020104 * 4), .data = 0x0004 },
	{ .addr = (0 + 0x020105 * 4), .data = 0x0005 },
	{ .addr = (0 + 0x020110 * 4), .data = 0x0000 },
	{ .addr = (0 + 0x020111 * 4), .data = 0x0001 },
	{ .addr = (0 + 0x020112 * 4), .data = 0x0002 },    // for MA borad : LPCAB2 => LPCAB2
	{ .addr = (0 + 0x020113 * 4), .data = 0x0003 },    // for MA borad : LPCAB3 => LPCAB3
	{ .addr = (0 + 0x020114 * 4), .data = 0x0004 },    // for MA borad : LPCAB4 => LPCAB4
	{ .addr = (0 + 0x020115 * 4), .data = 0x0005 },    // for MA borad : LPCAB5 => LPCAB5
	{ .addr = (0 + 0x0100A0 * 4), .data = 0x0001 },
	{ .addr = (0 + 0x0100A1 * 4), .data = 0x0003 },
	{ .addr = (0 + 0x0100A2 * 4), .data = 0x0006 },
	{ .addr = (0 + 0x0100A3 * 4), .data = 0x0007 },
	{ .addr = (0 + 0x0100A4 * 4), .data = 0x0004 },
	{ .addr = (0 + 0x0100A5 * 4), .data = 0x0005 },
	{ .addr = (0 + 0x0100A6 * 4), .data = 0x0000 },
	{ .addr = (0 + 0x0100A7 * 4), .data = 0x0002 },
	{ .addr = (0 + 0x0110A0 * 4), .data = 0x0000 },
	{ .addr = (0 + 0x0110A1 * 4), .data = 0x0001 },
	{ .addr = (0 + 0x0110A2 * 4), .data = 0x0006 },
	{ .addr = (0 + 0x0110A3 * 4), .data = 0x0003 },
	{ .addr = (0 + 0x0110A4 * 4), .data = 0x0004 },
	{ .addr = (0 + 0x0110A5 * 4), .data = 0x0002 },
	{ .addr = (0 + 0x0110A6 * 4), .data = 0x0007 },
	{ .addr = (0 + 0x0110A7 * 4), .data = 0x0005 },
	{ .addr = (0 + 0x0120A0 * 4), .data = 0x0002 },
	{ .addr = (0 + 0x0120A1 * 4), .data = 0x0006 },
	{ .addr = (0 + 0x0120A2 * 4), .data = 0x0007 },
	{ .addr = (0 + 0x0120A3 * 4), .data = 0x0003 },
	{ .addr = (0 + 0x0120A4 * 4), .data = 0x0004 },
	{ .addr = (0 + 0x0120A5 * 4), .data = 0x0005 },
	{ .addr = (0 + 0x0120A6 * 4), .data = 0x0001 },
	{ .addr = (0 + 0x0120A7 * 4), .data = 0x0000 },
	{ .addr = (0 + 0x0130A0 * 4), .data = 0x0000 },
	{ .addr = (0 + 0x0130A1 * 4), .data = 0x0002 },
	{ .addr = (0 + 0x0130A2 * 4), .data = 0x0007 },
	{ .addr = (0 + 0x0130A3 * 4), .data = 0x0006 },
	{ .addr = (0 + 0x0130A4 * 4), .data = 0x0004 },
	{ .addr = (0 + 0x0130A5 * 4), .data = 0x0003 },
	{ .addr = (0 + 0x0130A6 * 4), .data = 0x0005 },
	{ .addr = (0 + 0x0130A7 * 4), .data = 0x0001 },
	{ .addr = DDR_NO_DATA_SYMBOL, .data = 0 }
};



