/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2022 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : main.c
 ******************************************************************************/
#include <stdio.h>
#include "types.h"

#include "evk_gic.h"
#include "evk_uart.h"
#include "evk_emmc_hal.h"
#include "evk_emmc_std.h"
#include "evk_emmc_def.h"
#include "evk_emmc_cnf.h"
#include "evk_emmc_reg.h"
#include "evk_common.h"

/*-----------------------------------------------------------*/
int (*SecondLoaderMain)(struct st_boot_param* uboot_param);

extern void InitPFC(void);
extern void InitCPG(void);
extern void PowerOnRAMB(void);
extern void UartSetup(void);

extern void get_bootparam(uint32_t *buf, struct st_boot_param *param);
extern BOOL sum_check(struct st_boot_param param);
static int get_nextloaders_info(struct st_load_param *boot_param);

#define BASE_ADDR_CA53                  0xA3F02000
#define OFFSET_REG_RVA1CRL              0x28
#define OFFSET_REG_RVA1CRH              0x2C
#define OFFSET_REG_PSCR                 0x3C
#define OFFSET_REG_WFI_STA              0x404
#define OFFSET_REG_WFE_STA              0x408
#define OFFSET_REG_WFI_L2_STA           0x40C
#define BASE_ADRDR_PMC                  0xA3600000
#define PMC_INT_CLR_CPU1                0x078
#define BASE_ADDR_CPG                   0xA3500000
#define OFFSET_REG_CPG_RST8             0x61C
#define NCPUPORESET_RESET_ASSERT        (0x0<<1)
#define NCPUPORESET_RESET_DEASSERT      (0x1<<1)
#define NCPUPORESET_EN (0x1<<17)
#define NCORERESET1_RESET_ASSERT        (0x0<<3)
#define NCORERESET1_RESET_DEASSERT      (0x1<<3)
#define NCORERESET1_EN (0x1<<19)
#define CORE1_COLD_RESET_ASSERT         (NCPUPORESET_RESET_ASSERT + NCORERESET1_RESET_ASSERT) + \
                                        (NCPUPORESET_EN + NCORERESET1_EN)
#define CORE1_COLD_RESET_DEASSERT       (NCPUPORESET_RESET_DEASSERT + NCORERESET1_RESET_DEASSERT) + \
                                        (NCPUPORESET_EN + NCORERESET1_EN)
#define CORE1_RESET_VECTOR  0x80100000
#define WAKEUP_SECOND_MAXWAIT           100000 //100msec timeout


static uint8_t WakeupSecondary(unsigned char cpu)
{
    unsigned int wfe_status;
    unsigned int cur;
    unsigned int wait_cnt=0;

    uart0_print("[BL1] Wakeup secondary core...\n");

    //ca53 x(cpu) reset vector
    CMN_REG_Write32(BASE_ADDR_CA53+OFFSET_REG_RVA1CRL,  CORE1_RESET_VECTOR);

    CMN_REG_Write32(BASE_ADDR_CPG+OFFSET_REG_CPG_RST8,  CORE1_COLD_RESET_ASSERT);
    cur = CMN_REG_Read32(BASE_ADDR_CA53+OFFSET_REG_PSCR);
    CMN_REG_Write32(BASE_ADDR_CA53+OFFSET_REG_PSCR,     (cur | (0x1 << cpu)));
    CMN_REG_Write32(BASE_ADDR_CPG+OFFSET_REG_CPG_RST8,  CORE1_COLD_RESET_DEASSERT);

    //check to WFE status
    do{
        wait_cnt++;
        wfe_status = (CMN_REG_Read32(BASE_ADDR_CA53 + OFFSET_REG_WFE_STA) & 0x3);
        CMN_DelayInUS(1);
    } while( ((0x1 << cpu) != wfe_status) || (wait_cnt >= WAKEUP_SECOND_MAXWAIT) );

    if(wait_cnt >= WAKEUP_SECOND_MAXWAIT) {
        uart0_print("[BL1] Secondary core could not be changed the WFE status\n");
        return 0x00;
    } else {
        uart0_print("[BL1] Migration secondary core to WFE status\n");
        return 0x01;
    }
}


int main(void)
{
    volatile struct st_load_param boot_param;
    uint32_t read_block_size;
    uint8_t tmp_ret=0;

    /* initialize GIC driver */
    Init_GIC(0);

    /* Set Pin Function */
    InitPFC();

    /* Initialize CPG */
    InitCPG();

    /* Initialize RAMB */
    PowerOnRAMB();

    /* Initialize UART */
    UartSetup();

    uart0_print("[BL1] Boot Loader Version 1.00 for RZV2MA\n");

    /* Wakeup the Secondary CPU */
    tmp_ret = WakeupSecondary(1);
    if(tmp_ret != 0) 
    {
        /* Initialize eMMC */
        if(EMMC_SUCCESS != emmc_init(FALSE))
        {
            /*- Error occurred -*/
            uart0_print("[BL1] [Error] emmc_init()\n");
        }else
        {
            /* Power control eMMC */
            if(EMMC_SUCCESS != emmc_memcard_power(TRUE))
            {
                /*- Error occurred -*/
                uart0_print("[BL1] [Error] emmc_memcard_power()\n");
            }else
            {
                /* Mount control eMMC */
                if(EMMC_SUCCESS != emmc_mount())
                {
                    /*- Error occurred -*/
                    uart0_print("[BL1] [Error] emmc_mount error()\n");
                }else
                {
                    /* Access partition control eMMC */
                    if(EMMC_SUCCESS != emmc_select_partition(BOOT_IMAGE_PARTITION))
                    {
                        /*- Error occurred -*/
                        uart0_print("[BL1] [Error] emmc_select_partition()\n");
                    }else
                    {
                        /* Initialization operation ends normally */
                        uart0_print("[BL1] eMMC initialized\n");
                        tmp_ret = 0x02;
                    }
                }
            }
        }
    }

    /*- Check the execution result of the initialization operation -*/
    if(tmp_ret == 0x02)
    {
        if( get_nextloaders_info(&boot_param) == 0 )
        {
            read_block_size = boot_param.second_loader.size / EMM_BLOCK_SIZ;
            if(0 < boot_param.second_loader.size % EMM_BLOCK_SIZ)
            {
                read_block_size += 1;
            }

            /* Load the 2nd loader with RAMB area */
            if(EMMC_SUCCESS !=
                emmc_read_sector((uint32_t *)boot_param.second_loader.addr_load,
                SECOND_LOADER_BLOCK, read_block_size, 0))
            {
                /*- Error occurred -*/
                uart0_print("[BL1]  [Error] emmc_read_sector() for 2nd boot loader\n");
            }else
            {
                /* Checksum for 2nd bootloader */
                if(TRUE != sum_check(boot_param.second_loader))
                {
                    /*- Error occurred -*/
                    uart0_print("[BL1]  [Error] sum_check() for 2nd boot loader\n");
                }else
                {
                    /*- The acquisition process of 2nd bootloader was completed normally -*/
                    uart0_print("[BL1] Loaded the 2nd boot loader\n");

                    /* Start 2nd bootloader */
                    uart0_print("[BL1] the 2nd bootloader start\n");
                    SecondLoaderMain = (void*)SECOND_LOAD_MAIN_ADDR;
                    SecondLoaderMain(&boot_param.u_boot);

                    /* Set control Flag -*/
                    tmp_ret = 0x0f;
                }
            }
        }
    }

    /*- Check the execution result of the initialization operation -*/
    if(tmp_ret != 0x0f)
    {
        /* Error detected and operation terminated */
        uart0_print("[BL1] [Error] 1st loader is failed");
    }

    while(1)
    {
        __asm("nop");
        __asm("nop");
        __asm("nop");
    }

    return 0;
}

static int get_nextloaders_info(struct st_load_param *boot_param){
        
    uint32_t total_size, bootp_size;
    uint32_t boot_pram_buf[EMM_BLOCK_SIZ * BOOT_PARAM_BLOCK_SIZE / sizeof(uint32_t)];

    boot_param->blok_buf = boot_pram_buf;
    boot_param->second_loader.addr_load = (void*)BASEADDR_RAMB0;
    boot_param->u_boot.addr_load = (void*)U_BOOT_ADDR;

    /* Load boot parameter for 2nd loader */
    if(EMMC_SUCCESS != emmc_read_sector(boot_param->blok_buf,
                SECOND_LOADER_PARM,
                BOOT_PARAM_BLOCK_SIZE,
                LOADIMAGE_FLAGS_DMA_ENABLE))
    {
        /*- Error occurred -*/
        uart0_print("[BL1]  [Error] emmc_read_sector() for 2nd boot loader parameter\n");
        return -1;
    }

    uart0_print("[BL1] Loaded the boot parameter for 2nd boot\n");

    /* Load boot parameter for 2nd bootloader */
    get_bootparam(boot_param->blok_buf, &boot_param->second_loader);

    /* Load U-Boot to DDR */
    if(EMMC_SUCCESS != emmc_read_sector(boot_param->blok_buf,
                       U_BOOT_PARM,
                       BOOT_PARAM_BLOCK_SIZE,
                       LOADIMAGE_FLAGS_DMA_ENABLE))
    {
        /*- Error occurred -*/
        uart0_print("[BL1] [Error] emmc_read_sector() for U-Boot parameter\n");
        return -1;
    }
    uart0_print("[BL1] Loaded the boot parameter for U-Boot\n");

    /* Load boot parameter for uboot */
    get_bootparam(boot_param->blok_buf,&boot_param->u_boot);

    /* Check that the expected maximum size of the 2nd bootloader is not exceeded */
    if(SECOND_LOADER_MAX_SIZ < boot_param->second_loader.size)
    {
        /*- Error occurred -*/
        uart0_print("[BL1] [Error] Over size the 2nd boot loader\n");
        return -1;
    }

    /* Check that the expected total size until the uboot area */
    total_size = boot_param->u_boot.size + (U_BOOT_BLOCK * EMM_BLOCK_SIZ);
    if( total_size < bootp_size )
    {
        uart0_print("[BL1]  [Error] Over size the total area\n");
        return -1;
    }

    return 0;

}

/* End of file -*/
