/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2022 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : main.c
 ******************************************************************************/
#include <stdio.h>
#include "types.h"

#include "evk_uart.h"
#include "evk_emmc_hal.h"
#include "evk_emmc_std.h"
#include "evk_emmc_def.h"
#include "evk_emmc_cnf.h"
#include "evk_emmc_reg.h"
#include "evk_common.h"

/*-----------------------------------------------------------*/
void (*u_boot)(void);

extern int8_t PowerOnDDR(void);
extern void UartSetup(void);
extern void get_bootparam(uint32_t *buf, struct st_boot_param *param);
extern BOOL sum_check(struct st_boot_param param);


__attribute__((section(".entry")))
int main( struct st_boot_param *uboot_info )
{
    struct   st_load_param  boot_param;
    uint32_t read_block_size;
    uint8_t  tmp_ret=0;

    uart0_print("[BL2] 2nd boot loader entered_for RZV2MA\n");

    /*- Get uboot parameter from 1st loader -*/
    boot_param.u_boot.size = uboot_info->size;
    boot_param.u_boot.addr_load = uboot_info->addr_load;
    boot_param.u_boot.checksum = uboot_info->checksum;

    /*- Initialize DDR (Initial training) -*/
    tmp_ret = PowerOnDDR();

    /*- Check DDR Execution result of initial setting -*/
    if(tmp_ret)
    {
       /* Error detected and operation terminated */
       uart0_print("[BL2] [Error] 2nd loader is failed");

       while(1)
       {
           __asm("nop");
           __asm("nop");
           __asm("nop");
       }
    }else
    {
       /* Set Oepration Flag : normal End */
       tmp_ret = 0x08;
    }

    /* Initialize eMMC : Take over the execution result of 1stbootloader */
    emmc_force_state_reset();

    /*- Check the execution result of the initialization operation -*/
    if(tmp_ret)
    {
        read_block_size = boot_param.u_boot.size / EMM_BLOCK_SIZ;
        /* Check that the expected maximum size of the uboot is not exceeded */
        if(0 < (boot_param.u_boot.size % EMM_BLOCK_SIZ))
        {
            read_block_size += 1;
        }

        /* Load the u-boot with DDR area */
        if(EMMC_SUCCESS !=
               emmc_read_sector((uint32_t*)boot_param.u_boot.addr_load,
               U_BOOT_BLOCK, read_block_size, LOADIMAGE_FLAGS_DMA_ENABLE))
        {
            /*- Error occurred -*/
            uart0_print("[BL2] [Error] emmc_read_sector() for U-Boot\n");
        }else
        {
            /* Checksum for uboot */
            if(TRUE != sum_check(boot_param.u_boot))
            {
                /*- Error occurred -*/
                uart0_print("[BL2] [Error] sum_check() for U-Boot\n");
            }else
            {
                /*- The acquisition process of uboot was completed normally -*/
                uart0_print("[BL2] Loaded the U-Boot\n");

                /* Start U-Boot */
                uart0_print("[BL2] the U-Boot start\n");
                u_boot = (void*)U_BOOT_ADDR;
                u_boot();

                /* Set control Flag -*/
                tmp_ret = 0x0f;
            }
        }
    }

    /*- Check the execution result of the initialization operation -*/
    if(tmp_ret != 0x0f)
    {
        /* Error detected and operation terminated */
        uart0_print("[BL2] [Error] 2nd loader is failed");
    }

    while(1)
    {
        __asm("nop");
        __asm("nop");
        __asm("nop");
    }

    return 0;
}


/*- End of File -*/
